import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "redux/store";
import { addTodo, removeTodo, setTodoStatus } from "redux/todoSlice";

function Test() {
    //React Hooks
    const [todoDescription, setTodoDescription] = useState("");

    //React Redux Hooks
    const todoList = useSelector((state: RootState) => state);
    const dispatch = useDispatch<AppDispatch>();
    return (
        <div>
            <input className="border border-gray-600"
                onChange={(e) => setTodoDescription(e.target.value)}
                value={todoDescription}
            />
            <button
                color="primary"
                onClick={() => {
                    dispatch(addTodo(todoDescription));
                    setTodoDescription("");
                }}
            >
                Add Item
            </button>
            {todoList.map((todo) => (
                <ul key={todo.id}>
                    <li
                        style={{
                            textDecoration: todo.completed ? "line-through" : "none",
                        }}
                    >
                        {todo.description}
                    </li>
                </ul>))
}
        </div>
    )
}
export default Test;